var app = angular.module('ketchup.services', [
	'ketchup.utils',
	'ketchup.services.userService'
]);